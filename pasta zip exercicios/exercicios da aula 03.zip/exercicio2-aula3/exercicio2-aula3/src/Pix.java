public class Pix implements MetodoDePagamento {

    public void realizarPagamento(double valor) {
        System.out.println("Enviando pix de: R$"+ valor);
    }
    
}
