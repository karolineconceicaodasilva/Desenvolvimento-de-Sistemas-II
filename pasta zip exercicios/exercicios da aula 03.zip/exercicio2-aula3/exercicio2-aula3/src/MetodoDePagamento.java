public interface MetodoDePagamento{

    public void realizarPagamento(double valor);

}