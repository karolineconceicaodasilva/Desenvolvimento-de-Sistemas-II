public interface Autenticador{

    public void autenticar();
}