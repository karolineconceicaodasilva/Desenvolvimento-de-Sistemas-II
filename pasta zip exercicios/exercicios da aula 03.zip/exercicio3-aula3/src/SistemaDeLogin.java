public class SistemaDeLogin {

    public void realizarLogin(Autenticador autenticador) {
       autenticador.autenticar();
    }
}