public class ProcessadorDeImagem implements ProcessadorDeMidia {

    public void processar(){
        System.out.println("Processando imagem...");
    }

    public void carregar(){
        System.out.println("Carregando imagem...");
    }

}
