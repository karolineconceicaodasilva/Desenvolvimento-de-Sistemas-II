public interface ProcessadorDeMidia{

    public void processar();
    public void carregar();

}