public class ProcessadorDeAudio implements ProcessadorDeMidia {
    
    public void processar(){
        System.out.println("Processando áudio...");
    }

    public void carregar(){
        System.out.println("Carregando áudio...");
    }

}
