public class ProcessadorDeVideo implements ProcessadorDeMidia{
    
    public void processar(){
        System.out.println("Processando vídeo...");
    }

    public void carregar(){
        System.out.println("Carregando vídeo...");
    }

}
