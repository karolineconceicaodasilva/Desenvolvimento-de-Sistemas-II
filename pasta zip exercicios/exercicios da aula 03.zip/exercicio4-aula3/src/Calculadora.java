public interface Calculadora {
    
    public void calcularAdicao();
    public void calcularSubtracao();
    public void calcularMultiplicacao();
    public void calcularDivisao();
    public void calcularPotenciacao();

}
