package exercicio01;

public class Cirurgiao extends Medico{
    
   public void fazerIncisão(){
         System.out.println("Operar!");
    }
}
