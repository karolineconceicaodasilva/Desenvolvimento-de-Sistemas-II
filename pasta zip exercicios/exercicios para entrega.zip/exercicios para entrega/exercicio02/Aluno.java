package exercicio02;

public class Aluno extends Pessoa{

    public void codigoAluno(){
        System.out.println("0150055");
    }
  
}
