package exercicio02;

public class Computador extends Dispositivo {
    
    public void quantidadePorSala(){
        System.out.println("20");
    }
     public void quantidadeMouse(){
        System.out.println("20");
    }
     public void quantidadeTeclado(){
        System.out.println("20");
    }

}
