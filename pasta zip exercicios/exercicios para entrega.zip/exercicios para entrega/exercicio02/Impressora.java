package exercicio02;

public class Impressora extends Dispositivo{
    
    public void quantidadePorSala(){
        System.out.println("1");
    }
    public void quantidadeCartuchoPorSala(){
        System.out.println("2");
    }
}
