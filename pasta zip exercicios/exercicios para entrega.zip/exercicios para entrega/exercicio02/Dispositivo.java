package exercicio02;

public class Dispositivo{
    
    private String funcao;
    private int quantiaTotalEscola;
    
    public String getFuncao() {
        return funcao;
    }
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    public int getQuantiaTotalEscola() {
        return quantiaTotalEscola;
    }
    public void setQuantiaTotalEscola(int quantiaTotalEscola) {
        this.quantiaTotalEscola = quantiaTotalEscola;
    }
    
    
    
    
}

