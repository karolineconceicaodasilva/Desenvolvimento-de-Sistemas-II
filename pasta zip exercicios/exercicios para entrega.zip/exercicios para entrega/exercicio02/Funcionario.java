package exercicio02;

public class Funcionario extends Pessoa{
    
    public void funcao(){
        System.out.println("Professor!");
    }

}
