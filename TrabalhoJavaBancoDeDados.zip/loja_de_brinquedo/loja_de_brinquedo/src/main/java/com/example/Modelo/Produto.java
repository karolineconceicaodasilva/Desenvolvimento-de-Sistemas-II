package com.example.Modelo;

public class Produto {

    private int id;
    private String nome;
    private String decricao;
    private double valor;
    private int quantidadeEstoque;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDecricao() {
        return decricao;
    }

    public void setDecricao(String decricao) {
        this.decricao = decricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    @Override
    public String toString() {
        return "Produto [id=" + id + ", nome=" + nome + ", decricao=" + decricao + ", valor=" + valor
                + ", quantidadeEstoque=" + quantidadeEstoque + "]";
    }

}
