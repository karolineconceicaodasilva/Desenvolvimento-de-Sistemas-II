package com.example;

import com.example.Servico.MenuPrincipal;

public class Main {
    public static void main(String[] args) {
        
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.menuPrincipal();
    }
}